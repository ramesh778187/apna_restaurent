<!DOCTYPE html>
<html>
<head>
    <meta charset='utf-8'>
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <title>Login</title>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
    <link rel='stylesheet' type='text/css' media='screen' href='style.css'>
</head>
<body>
    <div class="wrapper">
        <h2 class="title">Login</h2>
        <form action="./index.php" method="POST" class="form">
            <div class="input-field">
                <label for="email" class="input-label">Email</label>
                <input type="email"  name="user" id="email" class="input" placeholder="Enter your email" required>
            </div>
            <div class="input-field">
                <label for="password" class="input-label">Password</label>
                <input type="password" name="pass" id="password" class="input" placeholder="Enter your password" required>
            </div>
        <input type="submit" value="login">
        <p>Create Account! <a href="register.php">Register</a></p>
        </form>
    </div>
</body>
</html>
<?php
$conn=new mysqli('localhost','root','','login-limits');
if ($_SERVER["REQUEST_METHOD"] == "POST"){
   $user=$_POST['user'];
   $pass= $_POST['pass'];
   $sql="SELECT * FROM users WHERE `email`='$user'  &&  `password`='$pass'";
   if($result=$conn->query($sql))
   {
        $row=$result->fetch_assoc();
        echo"kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk". var_dump($row);
   }
   else{
       echo "User is not available";
   }
}

?>