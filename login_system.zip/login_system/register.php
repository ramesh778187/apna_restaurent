

<!DOCTYPE html>
<html>
<head>
    <meta charset='utf-8'>
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <title>Login</title>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
    <link rel='stylesheet' type='text/css' media='screen' href='style.css'>
</head>
<body>
    <div class="wrapper">
        <h2 class="title">Register</h2>
        <form action="./register.php" method="post" class="form">
            <div class="input-field">
                <label for="name" class="input-label">Full Name</label>
                <input type="text"  name="name" 
                id="name" class="input" placeholder="Enter your full name" required>
            </div>
            <div class="input-field">
                <label for="email" class="input-label">Email</label>
                <input type="email"  name="email" id="email" class="input" placeholder="Enter your email" required>
            </div>
            <div class="input-field">
                <label for="password" class="input-label">Password</label>
                <input type="password" name="password" id="password" class="input" placeholder="Enter your password" required>
            </div>
            <div class="input-field">
                <label for="cpassword" class="input-label"> Confirm Password</label>
                <input type="text" name="cpassword" id="password" class="input" placeholder="Enter your confirm password" required>
            </div>
            <div class="input-field">
                <label for="limit" class="input-label">Login Limit</label>
                <select id="limit" name="limits" class="input" required>
                <option value="" disabled selected>Select Limit</option>
                    <option value="1">1</option>
                    <option value="2">2</option>
                    <option value="3">3</option>
                    <option value="4">4</option>
                    <option value="5">5</option>
                    <option value="6">6</option>
                    <option value="7">7</option>
                    <option value="8">8</option>
                </select>
            </div>
        <input type="submit" value="register">
        <p>You have already an account! <a href="index.php">Login</a></p>
        </frm>
    </div>
</body>
</html>

<?php

function redirect($url){
    header('location:' .$url,true,303);
    die();
    
}

$conn=new mysqli('localhost','root','','login-limits');

if ($_SERVER["REQUEST_METHOD"] == "POST"){
    $name=$_POST['name'];
    $email= $_POST['email'];
    $password=$_POST['password'];
    $cpassword= $_POST['cpassword'];
    $limits= $_POST['limits'];
    $sql="INSERT INTO `users`(`name`, `email`, `password`, `login_limits`, `login_used`)  VALUES ('$name','$email','$password','$cpassword','$limits')";
    if($conn->query($sql)===True){
       redirect('index.php');
    
    }
    else{
        echo "<h1 style='z-index:3;' >Not Inserted</h1>";
    }
}


?>